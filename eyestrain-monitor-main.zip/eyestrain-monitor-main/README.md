# Tested Development Environment

- Python 3.10.5 installed via Chocolatey
- Windows 10
- Using Python's venv

```ps
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
```

#### Voice by @marialeonyta on instagram
