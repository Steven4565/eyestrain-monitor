from customtkinter import *
from tkinter import *


def populate_activity_page(frame):
    pass
